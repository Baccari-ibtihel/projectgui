package projet_gui;

import javafx.application.Application;
import javafx.application.HostServices;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import projet_gui.Controllers.ControllerBase;

import java.io.IOException;

public class App extends Application {
    private static Scene scene;
    private static HostServices appHostServices;
    private static final String DEFAULT_FALLBACK_FXML = "page_login";

    @Override
    public void start(Stage stage) {
        appHostServices = getHostServices();
        scene = new Scene(new javafx.scene.layout.Pane(), 1280, 720);
        stage.setScene(scene);
        stage.show();
        navigateTo("page_dashboard");
    }

    public static HostServices getHostServicesInstance() {
        return appHostServices;
    }

    public static void navigateTo(String fxml) {
        navigateTo(fxml, DEFAULT_FALLBACK_FXML);
    }

    public static void navigateTo(String fxml, String fallbackFxml) {
        try {
            FXMLLoader loader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
            Parent root = loader.load();

            if (loader.getController() instanceof ControllerBase baseController) {
                if (baseController.canEnter()) {
                    scene.setRoot(root);
                    return;
                }
            }

            FXMLLoader fallbackLoader = new FXMLLoader(App.class.getResource(fallbackFxml + ".fxml"));
            scene.setRoot(fallbackLoader.load());
        } catch (IOException e) {
            System.err.println("Navigation error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}