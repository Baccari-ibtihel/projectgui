package projet_gui.Entities;

import java.sql.Timestamp;

public class Parcelle {
    private int id;
    private String nom;
    private Double longueur;
    private Double largeur;
    private String localisationCity;
    private Double latitude;
    private Double longitude;
    private Utilisateur proprietaire;
    private String imagePath;
    private Timestamp dateCreation;

    public Parcelle() {
    }

    public Parcelle(String nom, Double longueur, Double largeur, String localisationCity,
                    Utilisateur proprietaire, String imagePath) {
        this.nom = nom;
        this.longueur = longueur;
        this.largeur = largeur;
        this.localisationCity = localisationCity;
        this.proprietaire = proprietaire;
        this.imagePath = imagePath;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNom() { return nom; }
    public void setNom(String nom) {
        if (nom == null || nom.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be empty");
        }
        this.nom = nom;
    }

    public Double getLongueur() { return longueur; }
    public void setLongueur(Double longueur) {
        if (longueur == null || longueur <= 0) {
            throw new IllegalArgumentException("Length must be positive");
        }
        this.longueur = longueur;
    }

    public Double getLargeur() { return largeur; }
    public void setLargeur(Double largeur) {
        if (largeur == null || largeur <= 0) {
            throw new IllegalArgumentException("Width must be positive");
        }
        this.largeur = largeur;
    }

    public String getLocalisationCity() { return localisationCity; }
    public void setLocalisationCity(String localisationCity) {
        if (localisationCity == null || localisationCity.trim().isEmpty()) {
            throw new IllegalArgumentException("Location cannot be empty");
        }
        this.localisationCity = localisationCity;
    }

    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) {
        if (latitude != null && (latitude < -90 || latitude > 90)) {
            throw new IllegalArgumentException("Latitude must be between -90 and 90 degrees");
        }
        this.latitude = latitude;
    }

    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) {
        if (longitude != null && (longitude < -180 || longitude > 180)) {
            throw new IllegalArgumentException("Longitude must be between -180 and 180 degrees");
        }
        this.longitude = longitude;
    }

    public Utilisateur getProprietaire() { return proprietaire; }
    public void setProprietaire(Utilisateur proprietaire) {
        if (proprietaire == null) {
            throw new IllegalArgumentException("Owner cannot be null");
        }
        this.proprietaire = proprietaire;
    }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    public Timestamp getDateCreation() { return dateCreation; }
    public void setDateCreation(Timestamp dateCreation) { this.dateCreation = dateCreation; }

    @Override
    public String toString() {
        return "Parcelle{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", longueur=" + longueur +
                ", largeur=" + largeur +
                ", localisationCity='" + localisationCity + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", proprietaire=" + proprietaire +
                ", imagePath='" + imagePath + '\'' +
                ", dateCreation=" + dateCreation +
                '}';
    }
}