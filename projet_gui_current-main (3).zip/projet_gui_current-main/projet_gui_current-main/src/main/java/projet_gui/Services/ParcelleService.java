package projet_gui.Services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import projet_gui.Entities.Localisation;
import projet_gui.Entities.Parcelle;
import projet_gui.Entities.Utilisateur;
import projet_gui.Utils.DataSource;

public class ParcelleService {
    private Connection connection;
    private static ParcelleService instance;
    private GoogleMapsService googleMapsService;

    private ParcelleService() {
        connection = DataSource.getInstance().getCon();
        googleMapsService = GoogleMapsService.getInstance();
    }

    public static ParcelleService getInstance() {
        if (instance == null) {
            instance = new ParcelleService();
        }
        return instance;
    }

    /**
     * Crée une nouvelle parcelle dans la base de données avec géocodage.
     */
    public Parcelle create(Parcelle parcelle) throws SQLException {
        // Géocoder la localisation pour obtenir latitude/longitude
        try {
            Localisation loc = googleMapsService.geocode(parcelle.getLocalisationCity());
            if (loc != null) {
                parcelle.setLatitude(loc.getLatitude());
                parcelle.setLongitude(loc.getLongitude());
            }
        } catch (Exception e) {
            // Ne pas bloquer la création si le géocodage échoue
            System.err.println("Geocoding failed: " + e.getMessage());
        }

        String query = "INSERT INTO Parcelle (nom, longuerMetre, largeurMetre, localisationCity, latitude, longitude, proprietaireId, imagePath, dateCreation) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

        try (PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, parcelle.getNom());
            ps.setDouble(2, parcelle.getLongueur());
            ps.setDouble(3, parcelle.getLargeur());
            ps.setString(4, parcelle.getLocalisationCity());
            if (parcelle.getLatitude() != null) {
                ps.setDouble(5, parcelle.getLatitude());
            } else {
                ps.setNull(5, java.sql.Types.DOUBLE);
            }
            if (parcelle.getLongitude() != null) {
                ps.setDouble(6, parcelle.getLongitude());
            } else {
                ps.setNull(6, java.sql.Types.DOUBLE);
            }
            ps.setInt(7, parcelle.getProprietaire().getId());
            ps.setString(8, parcelle.getImagePath());

            int affectedRows = ps.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating parcelle failed, no rows affected.");
            }

            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    parcelle.setId(generatedKeys.getInt(1));
                    parcelle.setDateCreation(new Timestamp(System.currentTimeMillis()));
                    return parcelle;
                } else {
                    throw new SQLException("Creating parcelle failed, no ID obtained.");
                }
            }
        }
    }

    /**
     * Récupère une parcelle par son ID.
     */
    public Parcelle getById(int id) throws SQLException {
        String query = "SELECT p.*, u.id as userId, u.nom as userNom, u.prenom, u.email, u.role "
                + "FROM Parcelle p "
                + "JOIN Utilisateur u ON p.proprietaireId = u.id "
                + "WHERE p.id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToParcelle(rs);
                }
                return null;
            }
        }
    }

    /**
     * Récupère toutes les parcelles d'un utilisateur.
     */
    public List<Parcelle> getAllByUserId(int userId) throws SQLException {
        List<Parcelle> parcelles = new ArrayList<>();
        String query = "SELECT p.*, u.id as userId, u.nom as userNom, u.prenom, u.email, u.role "
                + "FROM Parcelle p "
                + "JOIN Utilisateur u ON p.proprietaireId = u.id "
                + "WHERE p.proprietaireId = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    parcelles.add(mapResultSetToParcelle(rs));
                }
            }
        }

        return parcelles;
    }

    /**
     * Récupère toutes les parcelles.
     */
    public List<Parcelle> getAll() throws SQLException {
        List<Parcelle> parcelles = new ArrayList<>();
        String query = "SELECT p.*, u.id as userId, u.nom as userNom, u.prenom, u.email, u.role "
                + "FROM Parcelle p "
                + "JOIN Utilisateur u ON p.proprietaireId = u.id";

        try (Statement stmt = connection.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(query)) {
                while (rs.next()) {
                    parcelles.add(mapResultSetToParcelle(rs));
                }
            }
        }

        return parcelles;
    }

    /**
     * Met à jour une parcelle.
     */
    public Parcelle update(Parcelle parcelle) throws SQLException {
        // Géocoder la localisation si elle a changé
        try {
            Localisation loc = googleMapsService.geocode(parcelle.getLocalisationCity());
            if (loc != null) {
                parcelle.setLatitude(loc.getLatitude());
                parcelle.setLongitude(loc.getLongitude());
            }
        } catch (Exception e) {
            System.err.println("Geocoding failed: " + e.getMessage());
        }

        String query = "UPDATE Parcelle SET nom = ?, longuerMetre = ?, largeurMetre = ?, "
                + "localisationCity = ?, latitude = ?, longitude = ?, proprietaireId = ?, imagePath = ? WHERE id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, parcelle.getNom());
            ps.setDouble(2, parcelle.getLongueur());
            ps.setDouble(3, parcelle.getLargeur());
            ps.setString(4, parcelle.getLocalisationCity());
            if (parcelle.getLatitude() != null) {
                ps.setDouble(5, parcelle.getLatitude());
            } else {
                ps.setNull(5, java.sql.Types.DOUBLE);
            }
            if (parcelle.getLongitude() != null) {
                ps.setDouble(6, parcelle.getLongitude());
            } else {
                ps.setNull(6, java.sql.Types.DOUBLE);
            }
            ps.setInt(7, parcelle.getProprietaire().getId());
            ps.setString(8, parcelle.getImagePath());
            ps.setInt(9, parcelle.getId());

            int affectedRows = ps.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Updating parcelle failed, no rows affected.");
            }

            return parcelle;
        }
    }

    /**
     * Supprime une parcelle.
     */
    public boolean delete(int id) throws SQLException {
        String query = "DELETE FROM Parcelle WHERE id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);

            int affectedRows = ps.executeUpdate();

            return affectedRows > 0;
        }
    }

    /**
     * Mappe un ResultSet à un objet Parcelle.
     */
    private Parcelle mapResultSetToParcelle(ResultSet rs) throws SQLException {
        Parcelle parcelle = new Parcelle();
        parcelle.setId(rs.getInt("id"));
        parcelle.setNom(rs.getString("nom"));
        parcelle.setLongueur(rs.getDouble("longuerMetre"));
        parcelle.setLargeur(rs.getDouble("largeurMetre"));
        parcelle.setLocalisationCity(rs.getString("localisationCity"));
        parcelle.setLatitude(rs.getDouble("latitude"));
        if (rs.wasNull()) {
            parcelle.setLatitude(null);
        }
        parcelle.setLongitude(rs.getDouble("longitude"));
        if (rs.wasNull()) {
            parcelle.setLongitude(null);
        }
        parcelle.setImagePath(rs.getString("imagePath"));
        parcelle.setDateCreation(rs.getTimestamp("dateCreation"));

        Utilisateur proprietaire = new Utilisateur();
        proprietaire.setId(rs.getInt("userId"));
        proprietaire.setNom(rs.getString("userNom"));
        proprietaire.setPrenom(rs.getString("prenom"));
        proprietaire.setEmail(rs.getString("email"));

        parcelle.setProprietaire(proprietaire);

        return parcelle;
    }
}