package projet_gui.Services;

import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.errors.ApiException;
import com.google.maps.model.GeocodingResult;
import com.google.maps.model.LatLng;
import projet_gui.Entities.Localisation;

import java.io.IOException;

public class GoogleMapsService {
    public static String API_KEY = "AIzaSyAPZfMmJ9zuZTE_RmRezYF-vO9lv655PcU";
    private static GoogleMapsService instance;
    private GeoApiContext context;

    private GoogleMapsService() {
        context = new GeoApiContext.Builder()
                .apiKey(API_KEY)
                .build();
    }

    public static GoogleMapsService getInstance() {
        if (instance == null) {
            instance = new GoogleMapsService();
        }
        return instance;
    }

    public Localisation geocode(String address) throws IOException, InterruptedException, ApiException {
        if (address == null || address.trim().isEmpty()) {
            throw new IllegalArgumentException("Address cannot be empty");
        }
        try {
            GeocodingResult[] results = GeocodingApi.geocode(context, address).await();
            if (results.length > 0) {
                LatLng location = results[0].geometry.location;
                Localisation loc = new Localisation(results[0].formattedAddress, location.lat, location.lng);
                System.out.println("Geocoded " + address + " to " + loc);
                return loc;
            } else {
                System.err.println("No geocoding results for address: " + address);
                return null;
            }
        } catch (Exception e) {
            System.err.println("Geocoding error for address " + address + ": " + e.getMessage());
            throw e;
        }
    }

    public String generateMapHtml(String locationName, double lat, double lng) {
        String escapedLocationName = locationName.replace("\"", "\\\"");
        return String.format("""
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        #map { height: 100%%; width: 100%%; }
                        html, body { height: 100%%; margin: 0; padding: 0; }
                        #map-type-control { position: absolute; top: 10px; right: 10px; z-index: 1; }
                        #map-type-control button { margin-left: 5px; padding: 5px 10px; cursor: pointer; }
                    </style>
                </head>
                <body>
                    <div id="map-type-control">
                        <button onclick="setMapType('roadmap')">Plan</button>
                        <button onclick="setMapType('satellite')">Satellite</button>
                    </div>
                    <div id="map"></div>
                    <script>
                        let map;
                        function initMap() {
                            try {
                                const location = { lat: %f, lng: %f };
                                map = new google.maps.Map(document.getElementById("map"), {
                                    zoom: 15,
                                    center: location,
                                    mapTypeId: 'roadmap',
                                    mapTypeControl: false,
                                    streetViewControl: true,
                                    fullscreenControl: true,
                                });
                                new google.maps.Marker({
                                    position: location,
                                    map: map,
                                    title: "%s"
                                });
                            } catch (error) {
                                document.getElementById("map").innerHTML = "<p>Error loading map: " + error.message + "</p>";
                                console.error("Map error:", error);
                            }
                        }
                        function setMapType(type) {
                            map.setMapTypeId(type);
                        }
                        window.onerror = function(msg, url, lineNo, columnNo, error) {
                            document.getElementById("map").innerHTML = "<p>JavaScript error: " + msg + "</p>";
                            return false;
                        }
                    </script>
                    <script async defer
                        src="https://maps.googleapis.com/maps/api/js?key=%s&callback=initMap"
                        onerror="document.getElementById('map').innerHTML='<p>Failed to load Google Maps API</p>';">
                    </script>
                </body>
                </html>
                """, lat, lng, escapedLocationName, API_KEY);
    }

    public void resetApiKey(String newApiKey) {
        if (newApiKey == null || newApiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("API key cannot be empty");
        }
        context.shutdown();
        API_KEY = newApiKey;
        context = new GeoApiContext.Builder()
                .apiKey(newApiKey)
                .build();
    }
    public static void main(String[] args) throws Exception {
        GoogleMapsService service = GoogleMapsService.getInstance();
        Localisation loc = service.geocode("V5X0Q+2XP, Cebelat Ben Ammar, Tunisie");
        System.out.println(loc);
    }
}