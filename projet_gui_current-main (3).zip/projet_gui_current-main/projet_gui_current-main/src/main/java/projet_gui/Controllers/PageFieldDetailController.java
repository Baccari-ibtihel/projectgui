package projet_gui.Controllers;

import javafx.application.HostServices;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Callback;

import projet_gui.App;
import projet_gui.Entities.Localisation;
import projet_gui.Services.AuthService;
import projet_gui.Services.ParcelleService;
import projet_gui.Utils.Alerts;
import projet_gui.Utils.FileDialogUtils;
import projet_gui.Services.ParcelleCultureService;
import projet_gui.Entities.Parcelle;
import projet_gui.Entities.ParcelleCulture;
import projet_gui.Services.GoogleMapsService;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;

import com.google.maps.errors.ApiException;
import javafx.scene.web.WebView;

public class PageFieldDetailController extends ControllerBaseWithSidebar {

    @FXML
    private Label fieldTitleLabel;

    @FXML
    private StackPane imageContainer;

    @FXML
    private ImageView fieldImageView;

    @FXML
    private Label noImageLabel;

    @FXML
    private TextField fieldNameField;

    @FXML
    private TextField longueurField;

    @FXML
    private TextField largeurField;

    @FXML
    private TextField locationField;

    @FXML
    private Label areaLabel;

    @FXML
    private Label creationDateLabel;

    @FXML
    private TableView<ParcelleCulture> cropsTable;

    @FXML
    private TableColumn<ParcelleCulture, String> cropNameColumn;

    @FXML
    private TableColumn<ParcelleCulture, String> cropStatusColumn;

    @FXML
    private TableColumn<ParcelleCulture, Double> cropWaterNeedsColumn;

    @FXML
    private TableColumn<ParcelleCulture, Double> cropNutrientNeedsColumn;

    @FXML
    private TableColumn<ParcelleCulture, Void> cropActionsColumn;

    @FXML
    private WebView mapView;

    @FXML
    private TextField addressTestField; // Nouveau champ pour tester l'adresse

    @FXML
    private HBox weatherContainer;

    private ParcelleService parcelleService;
    private ParcelleCultureService parcelleCultureService;
    private GoogleMapsService googleMapsService;
    private Parcelle currentParcelle;
    private static int selectedParcelleId = -1;

    public static void setSelectedParcelleId(int id) {
        selectedParcelleId = id;
    }

    @Override
    public void initializePageContent() {
        parcelleService = ParcelleService.getInstance();
        parcelleCultureService = ParcelleCultureService.getInstance();
        googleMapsService = GoogleMapsService.getInstance();

        // Setup crops table
        setupCropsTable();

        // Load the selected parcelle
        loadParcelle();

        // Load crops data
        loadCropsData();

        // Initialize map error handling
        mapView.getEngine().getLoadWorker().exceptionProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                System.err.println("Map load error: " + newVal.getMessage());
                Localisation loc = null;
                Alerts.showAlert(Alert.AlertType.ERROR, "Map Error", "Failed to load map: " + newVal.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
            }
        });

        // Ajouter un listener pour les erreurs JavaScript
        mapView.getEngine().setOnError(event -> System.err.println("WebView JS error: " + event.getMessage()));
    }

    @Override
    public boolean canEnter() {
        return AuthService.getInstance().isAuthenticated();
    }

    private void loadParcelle() {
        Localisation loc = null;
        try {
            if (selectedParcelleId == -1) {
                Alerts.showAlert(Alert.AlertType.ERROR, "Error", "No field selected", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                App.navigateTo("page_fields");
                return;
            }

            currentParcelle = parcelleService.getById(selectedParcelleId);
            if (currentParcelle == null) {
                Alerts.showAlert(Alert.AlertType.ERROR, "Error", "Field not found", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                App.navigateTo("page_fields");
                return;
            }

            updateUI();
        } catch (SQLException e) {
            e.printStackTrace();
            Alerts.showAlert(Alert.AlertType.ERROR, "Error", "Failed to load field: " + e.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
            App.navigateTo("page_fields");
        }
    }

    private void updateUI() {
        fieldTitleLabel.setText(currentParcelle.getNom());
        fieldNameField.setText(currentParcelle.getNom());
        longueurField.setText(String.valueOf(currentParcelle.getLongueur()));
        largeurField.setText(String.valueOf(currentParcelle.getLargeur()));
        locationField.setText(currentParcelle.getLocalisationCity());

        double area = currentParcelle.getLongueur() * currentParcelle.getLargeur();
        areaLabel.setText(String.format("%.2f m²", area));

        if (currentParcelle.getDateCreation() != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            creationDateLabel.setText(dateFormat.format(currentParcelle.getDateCreation()));
        } else {
            creationDateLabel.setText("-");
        }

        updateImage();
        updateMap();
    }

    private void updateImage() {
        String imagePath = currentParcelle.getImagePath();
        if (imagePath != null && !imagePath.isEmpty()) {
            File imageFile = new File(imagePath);
            if (imageFile.exists()) {
                Image image = new Image(imageFile.toURI().toString());
                fieldImageView.setImage(image);
                fieldImageView.setVisible(true);
                noImageLabel.setVisible(false);
                return;
            }
        }

        fieldImageView.setImage(null);
        fieldImageView.setVisible(false);
        noImageLabel.setVisible(true);
    }

    private void updateMap() {
        Localisation loc = null;
        try {
            String location = currentParcelle.getLocalisationCity();
            Double lat = currentParcelle.getLatitude();
            Double lng = currentParcelle.getLongitude();

            if (location == null || location.trim().isEmpty()) {
                mapView.getEngine().loadContent("<p>No location specified</p>");
                return;
            }

            if (lat != null && lng != null && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
                String mapHtml = googleMapsService.generateMapHtml(location, lat, lng);
                mapView.getEngine().loadContent(mapHtml);
            } else {
                loc = googleMapsService.geocode(location);
                if (loc != null) {
                    currentParcelle.setLatitude(loc.getLatitude());
                    currentParcelle.setLongitude(loc.getLongitude());
                    parcelleService.update(currentParcelle);
                    String mapHtml = googleMapsService.generateMapHtml(loc.getNomCity(), loc.getLatitude(), loc.getLongitude());
                    mapView.getEngine().loadContent(mapHtml);
                } else {
                    mapView.getEngine().loadContent("<p>Unable to geocode location: " + location + "</p>");
                    Alerts.showAlert(Alert.AlertType.WARNING, "Map Warning", "Could not find coordinates for location: " + location, "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                }
            }
        } catch (ApiException | IOException | InterruptedException | SQLException e) {
            e.printStackTrace();
            mapView.getEngine().loadContent("<p>Error loading map: " + e.getMessage() + "</p>");
            Alerts.showAlert(Alert.AlertType.ERROR, "Map Error", "Failed to load map: " + e.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
        }
    }

    @FXML
    private void testAddress(ActionEvent event) {
        String address = addressTestField.getText();
        Localisation loc = null;
        if (address == null || address.trim().isEmpty()) {
            Alerts.showAlert(Alert.AlertType.ERROR, "Validation Error", "Please enter an address to test.", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
            return;
        }

        try {
            loc = googleMapsService.geocode(address);
            if (loc != null) {
                String mapHtml = googleMapsService.generateMapHtml(loc.getNomCity(), loc.getLatitude(), loc.getLongitude());
                mapView.getEngine().loadContent(mapHtml);
                Alerts.showAlert(Alert.AlertType.INFORMATION, "Success", "Address geocoded successfully",
                        "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
            } else {
                mapView.getEngine().loadContent("<p>Unable to geocode address: " + address + "</p>");
                Alerts.showAlert(Alert.AlertType.WARNING, "Geocoding Failed", "Could not find coordinates for address: " + address, "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
            }
        } catch (ApiException | IOException | InterruptedException e) {
            e.printStackTrace();
            mapView.getEngine().loadContent("<p>Error geocoding address: " + e.getMessage() + "</p>");
            Alerts.showAlert(Alert.AlertType.ERROR, "Geocoding Error", "Failed to geocode address: " + e.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
        }
    }

    private void setupCropsTable() {
        cropNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getCulture().getNom()));

        cropStatusColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getStatut()));

        cropWaterNeedsColumn.setCellValueFactory(cellData ->
                new SimpleDoubleProperty(cellData.getValue().getCulture().getBesoinEau()).asObject());

        cropNutrientNeedsColumn.setCellValueFactory(cellData ->
                new SimpleDoubleProperty(cellData.getValue().getCulture().getBesoinNutriments()).asObject());

        cropActionsColumn.setCellFactory(createCropActionsColumnCellFactory());
    }

    private Callback<TableColumn<ParcelleCulture, Void>, TableCell<ParcelleCulture, Void>> createCropActionsColumnCellFactory() {
        return param -> new TableCell<>() {
            private final Button removeBtn = new Button("Remove");
            private final HBox pane = new HBox(5, removeBtn);

            {
                removeBtn.getStyleClass().add("button-small");
                removeBtn.getStyleClass().add("button-danger");
                pane.setAlignment(Pos.CENTER);

                removeBtn.setOnAction(event -> {
                    ParcelleCulture parcelleCulture = getTableView().getItems().get(getIndex());
                    removeCrop(parcelleCulture);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : pane);
            }
        };
    }

    private void loadCropsData() {
        try {
            if (currentParcelle != null) {
                List<ParcelleCulture> parcelleCultures = parcelleCultureService.getAllByParcelleId(currentParcelle.getId());
                cropsTable.setItems(FXCollections.observableArrayList(parcelleCultures));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Localisation loc = null;
            Alerts.showAlert(Alert.AlertType.ERROR, "Error", "Failed to load crops: " + e.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
        }
    }

    @FXML
    private void navigateToFields(ActionEvent event) {
        App.navigateTo("page_fields");
    }

    @FXML
    private void chooseImage(ActionEvent event) {
        String imagePath = FileDialogUtils.showImageChooser((Stage) fieldNameField.getScene().getWindow());
        if (imagePath != null) {
            currentParcelle.setImagePath(imagePath);
            updateImage();
        }
    }

    @FXML
    private void saveFieldChanges(ActionEvent event) {
        Localisation loc = null;
        try {
            if (fieldNameField.getText().trim().isEmpty()) {
                Alerts.showAlert(Alert.AlertType.ERROR, "Validation Error", "Field name is required", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                return;
            }

            if (locationField.getText().trim().isEmpty()) {
                Alerts.showAlert(Alert.AlertType.ERROR, "Validation Error", "Location is required", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                return;
            }

            double longueur, largeur;
            try {
                longueur = Double.parseDouble(longueurField.getText());
                if (longueur <= 0) {
                    Alerts.showAlert(Alert.AlertType.ERROR, "Validation Error", "Length must be a positive number", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                    return;
                }
            } catch (NumberFormatException e) {
                Alerts.showAlert(Alert.AlertType.ERROR, "Validation Error", "Please enter a valid number for length", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                return;
            }

            try {
                largeur = Double.parseDouble(largeurField.getText());
                if (largeur <= 0) {
                    Alerts.showAlert(Alert.AlertType.ERROR, "Validation Error", "Width must be a positive number", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                    return;
                }
            } catch (NumberFormatException e) {
                Alerts.showAlert(Alert.AlertType.ERROR, "Validation Error", "Please enter a valid number for width", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                return;
            }

            currentParcelle.setNom(fieldNameField.getText());
            currentParcelle.setLongueur(longueur);
            currentParcelle.setLargeur(largeur);
            currentParcelle.setLocalisationCity(locationField.getText());

            parcelleService.update(currentParcelle);
            updateUI();
            Alerts.showAlert(Alert.AlertType.INFORMATION, "Success", "Field updated successfully", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
        } catch (SQLException e) {
            e.printStackTrace();
            Alerts.showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to save field: " + e.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
        } catch (Exception e) {
            e.printStackTrace();
            Alerts.showAlert(Alert.AlertType.ERROR, "Error", "An unexpected error occurred: " + e.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
        }
    }

    @FXML
    private void openMapInBrowser(ActionEvent event) {
        Localisation loc = null;
        try {
            if (currentParcelle != null && !currentParcelle.getLocalisationCity().isEmpty()) {
                loc = googleMapsService.geocode(currentParcelle.getLocalisationCity());
                if (loc != null) {
                    String url = String.format("https://www.google.com/maps/@%f,%f,15z",
                            loc.getLatitude(),
                            loc.getLongitude());
                    HostServices hostServices = App.getHostServicesInstance();
                    if (hostServices != null) {
                        hostServices.showDocument(url);
                    } else {
                        Alerts.showAlert(Alert.AlertType.ERROR, "Error", "Could not access browser services", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                    }
                } else {
                    Alerts.showAlert(Alert.AlertType.ERROR, "Error", "Could not geocode location: " + currentParcelle.getLocalisationCity(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                }
            }
        } catch (ApiException | IOException | InterruptedException e) {
            Alerts.showAlert(Alert.AlertType.ERROR, "Error", "Could not open map: " + e.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
        }
    }

    @FXML
    private void manageCrops(ActionEvent event) {
        App.navigateTo("page_crops");
    }

    private void removeCrop(ParcelleCulture parcelleCulture) {
        Localisation loc = null;
        try {
            boolean deleted = parcelleCultureService.delete(parcelleCulture.getId());
            if (deleted) {
                loadCropsData();
                Alerts.showAlert(Alert.AlertType.INFORMATION, "Success", "Crop removed successfully", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
            } else {
                Alerts.showAlert(Alert.AlertType.ERROR, "Error", "Failed to remove crop", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Alerts.showAlert(Alert.AlertType.ERROR, "Error", "Failed to remove crop: " + e.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
        }
    }

    @FXML
    private void resetApiKey(ActionEvent event) {
        TextInputDialog dialog = new TextInputDialog(GoogleMapsService.API_KEY);
        dialog.setTitle("Reset Google Maps API Key");
        dialog.setHeaderText("Enter new Google Maps API Key");
        dialog.setContentText("Key:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(key -> {
            Localisation loc = null;
            try {
                googleMapsService.resetApiKey(key);
                Alerts.showAlert(Alert.AlertType.INFORMATION, "Success", "API Key updated successfully", "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
                updateMap();
            } catch (IllegalArgumentException e) {
                assert loc != null;
                Alerts.showAlert(Alert.AlertType.ERROR, "Error", "Invalid API Key: " + e.getMessage(), "Location: " + loc.getNomCity() + "\nLatitude: " + loc.getLatitude() + "\nLongitude: " + loc.getLongitude());
            }
        });
    }
}