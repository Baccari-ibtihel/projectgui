module projet_gui {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires javafx.graphics;
    requires google.maps.services;
    requires javafx.web;

    opens projet_gui.Controllers to javafx.fxml;
    exports projet_gui;
    exports projet_gui.Controllers;
}
